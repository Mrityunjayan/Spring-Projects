package com.luv2code.hibernate.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.luv2code.hibernate.demo.entity.Course;
import com.luv2code.hibernate.demo.entity.Instructor;
import com.luv2code.hibernate.demo.entity.InstructorDetail;
import com.luv2code.hibernate.demo.entity.Review;
import com.luv2code.hibernate.demo.entity.Student;

public class CreateCoursesAndReviewsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Instructor.class)
				.addAnnotatedClass(InstructorDetail .class)
				.addAnnotatedClass(Course.class)
				.addAnnotatedClass(Review.class)
				.buildSessionFactory();
		Session session =factory.getCurrentSession();
		try {
			session.beginTransaction();
			Course tempcourse=new Course("GTA VI - nuttertools");
			tempcourse.addReview(new Review("will not come"));
			tempcourse.addReview(new Review("adult only game"));
			tempcourse.addReview(new Review("Bugs free"));
			System.out.println(tempcourse);System.out.println(tempcourse.getReviews());
			session.save(tempcourse);
			session.getTransaction().commit();
			System.out.println("Done.");
		}
		finally {
			session.close();  
			factory.close();
		}
	}

}
